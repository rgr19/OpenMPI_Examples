//
// Created by Nicolas A Perez on 2/11/18.
//

#ifndef HOMEWORK2_COLLECTIVE_ADD_H
#define HOMEWORK2_COLLECTIVE_ADD_H

int add_all(int value, int root);

#endif //HOMEWORK2_COLLECTIVE_ADD_H
