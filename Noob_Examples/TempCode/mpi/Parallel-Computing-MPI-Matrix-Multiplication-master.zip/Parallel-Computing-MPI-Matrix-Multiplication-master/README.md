# Parallel-Computing-MPI-Matrix-Multiplication
Cannon Algorithm Implementation for matrix multiplication using MPI

Cannon's Algorithm is very scalable. 

![Iso-efficiency Analisys Cannon Algorithm](https://github.com/anicolaspp/Parallel-Computing-MPI-Matrix-Multiplication/blob/master/IMG_2496.PNG)
