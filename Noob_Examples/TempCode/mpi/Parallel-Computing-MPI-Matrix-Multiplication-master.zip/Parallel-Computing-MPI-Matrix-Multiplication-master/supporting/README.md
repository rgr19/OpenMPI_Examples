
execute 

```
> make 
```

It shoudl create the following outputs:

1. genmat  -> to generate matrices of a specific size.
2. prtmat  -> to print a matrix.
3. seqmm   -> sequential matrix multiplication algorithm for validation.



