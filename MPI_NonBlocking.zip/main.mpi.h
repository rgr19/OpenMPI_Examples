#pragma once

#ifndef TEMP_MASTER_MAIN_MPI_H
#define TEMP_MASTER_MAIN_MPI_H


#include <stdio.h>
#include <mpi.h>


//#include "structs.h"
#include "MpiSlave.h"
#include "MpiMaster.h"







int main_mpi(int argc, char **argv);


#endif //TEMP_MASTER_MAIN_MPI_H
